<?php

require_once 'koneksi.php';

class Mahasiswa {
    private string $nim;
    private string $nama;
	private string $email;
    private string $hp;

    public function __construct($nim, $nama, $email, $hp) {
        $this->nim = $nim;
        $this->nama = $nama;
        $this->email = $email;
        $this->hp = $hp;
    }
    public function simpanKeDatabase() {
        global $koneksi; 

        $query = "INSERT INTO mahasiswa (nim, nama, email, hp) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($koneksi, $query);
        mysqli_stmt_bind_param($stmt, 'ssss', $this->nim, $this->nama, $this->email, $this->hp);
        mysqli_stmt_execute($stmt);
    }
}
$mahasiswa = new Mahasiswa($_POST['nim'], $_POST['nama'], $_POST['email'], $_POST['hp']);
$mahasiswa->simpanKeDatabase();

header("location:index.php");
?>
