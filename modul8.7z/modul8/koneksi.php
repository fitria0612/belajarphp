<?php
   
   $servername = "localhost";
   $username = "root";
   $password = "";
   $dbname = "akamedik0";

    // Membuat koneksi
    $koneksi = new mysqli($servername, $username, $password, $dbname);

    // Memeriksa koneksi
    if ($koneksi->connect_error) {
        die("Koneksi database gagal: " . $koneksi->connect_error);
    }
    echo "Koneksi berhasil";
?>
