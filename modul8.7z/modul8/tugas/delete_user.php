<?php
// koneksi ke database
$conn = new mysqli("localhost", "root", "", "db_pengguna");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

session_start();
if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit();
}

$id = $_SESSION["id"];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $password = $_POST["password"];

    $sql = "SELECT * FROM pengguna WHERE id='$id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row["password"])) {
            $sql_delete = "DELETE FROM pengguna WHERE id='$id'";
            if ($conn->query($sql_delete) === TRUE) {
                session_destroy();
                header("Location: login.php");
            } else {
                echo "Error: " . $sql_delete . "<br>" . $conn->error;
            }
        } else {
            echo "Password salah.";
        }
    } else {
        echo "Data tidak ditemukan.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hapus Pengguna</title>
</head>
<body>
    <h2>Hapus Pengguna</h2>
    <p>Apakah Anda yakin ingin menghapus akun Anda?</p>
    <form method="post" action="">
        <label>Password:</label><br>
        <input type="password" name="password" required><br>
        <button type="submit">Hapus</button>
    </form>
    <a href="data.php">Batal</a>
</body>
</html>
