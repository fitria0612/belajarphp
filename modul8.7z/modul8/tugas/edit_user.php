<?php
// koneksi ke database
$conn = new mysqli("localhost", "root", "", "db_pengguna");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

session_start();
if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit();
}

$id = $_SESSION["id"];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_lengkap = $conn->real_escape_string($_POST["nama_lengkap"]);
    $email = $conn->real_escape_string($_POST["email"]);
    $no_telepon = $conn->real_escape_string($_POST["no_telepon"]);

    $sql = "UPDATE pengguna SET nama_lengkap='$nama_lengkap', email='$email', no_telepon='$no_telepon' WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        header("Location: data.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$sql = "SELECT * FROM pengguna WHERE id='$id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Data tidak ditemukan.";
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Pengguna</title>
</head>
<body>
    <h2>Edit Pengguna</h2>
    <form method="post" action="">
        <label>Nama Lengkap:</label><br>
        <input type="text" name="nama_lengkap" value="<?php echo $row["nama_lengkap"]; ?>" required><br>
        <label>Email:</label><br>
        <input type="email" name="email" value="<?php echo $row["email"]; ?>" required><br>
        <label>No Telepon:</label><br>
        <input type="text" name="no_telepon" value="<?php echo $row["no_telepon"]; ?>" required><br>
        <button type="submit">Update</button>
    </form>
</body>
</html>
