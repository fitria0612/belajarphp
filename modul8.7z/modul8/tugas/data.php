<?php
// koneksi ke database
$conn = new mysqli("localhost", "root", "", "db_pengguna");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

session_start();
if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit();
}

$id = $_SESSION["id"];
$sql = "SELECT * FROM pengguna WHERE id='$id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Data tidak ditemukan.";
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Pengguna</title>
</head>
<body>
    <h2>Data Pengguna</h2>
    <table border="1">
        <tr>
            <th>Nama Lengkap</th>
            <th>Email</th>
            <th>No Telepon</th>
            <th>Aksi</th>
        </tr>
        <tr>
            <td><?php echo $row["nama_lengkap"]; ?></td>
            <td><?php echo $row["email"]; ?></td>
            <td><?php echo $row["no_telepon"]; ?></td>
            <td>
                <a href="edit_user.php?id=<?php echo $row["id"]; ?>">Edit</a>
                <a href="delete_user.php?id=<?php echo $row["id"]; ?>">Hapus</a>
            </td>
        </tr>
    </table>
</body>
</html>
