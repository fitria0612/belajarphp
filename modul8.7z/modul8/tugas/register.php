<?php
// koneksi ke database
$conn = new mysqli("localhost", "root", "", "db_pengguna");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_lengkap = $conn->real_escape_string($_POST["nama_lengkap"]);
    $email = $conn->real_escape_string($_POST["email"]);
    $no_telepon = $conn->real_escape_string($_POST["no_telepon"]);
    $password = password_hash($_POST["password"], PASSWORD_BCRYPT);

    $sql = "INSERT INTO pengguna (nama_lengkap, email, no_telepon, password) VALUES ('$nama_lengkap', '$email', '$no_telepon', '$password')";

    if ($conn->query($sql) === TRUE) {
        header("Location: login.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
</head>
<body>
    <h2>Form Registrasi</h2>
    <form method="post" action="">
        <label>Nama Lengkap:</label><br>
        <input type="text" name="nama_lengkap" required><br>
        <label>Email:</label><br>
        <input type="email" name="email" required><br>
        <label>No Telepon:</label><br>
        <input type="text" name="no_telepon" required><br>
        <label>Password:</label><br>
        <input type="password" name="password" required><br>
        <button type="submit">Daftar</button>
    </form>
    <a href="login.php">Login</a>
</body>
</html>
