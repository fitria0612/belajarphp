<?php
class Rawat {
    private $conn;
    private $table_name = "rawat";

    public $id_rawat;
    public $id_pasien;
    public $id_dokter;
    public $diagnosis;
    public $obat;
    public $tgl_rawat;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        $query = "INSERT INTO " . $this->table_name . " SET id_pasien=:id_pasien, id_dokter=:id_dokter, diagnosis=:diagnosis, obat=:obat, tgl_rawat=:tgl_rawat";

        $stmt = $this->conn->prepare($query);

        $this->id_pasien=htmlspecialchars(strip_tags($this->id_pasien));
        $this->id_dokter=htmlspecialchars(strip_tags($this->id_dokter));
        $this->diagnosis=htmlspecialchars(strip_tags($this->diagnosis));
        $this->obat=htmlspecialchars(strip_tags($this->obat));
        $this->tgl_rawat=htmlspecialchars(strip_tags($this->tgl_rawat));

        $stmt->bindParam(":id_pasien", $this->id_pasien);
        $stmt->bindParam(":id_dokter", $this->id_dokter);
        $stmt->bindParam(":diagnosis", $this->diagnosis);
        $stmt->bindParam(":obat", $this->obat);
        $stmt->bindParam(":tgl_rawat", $this->tgl_rawat);

        if($stmt->execute()) {
            return true;
        }

        return false;
    }

    public function read() {
        $query = "SELECT * FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt;
    }

    public function update() {
        $query = "UPDATE " . $this->table_name . " SET id_pasien=:id_pasien, id_dokter=:id_dokter, diagnosis=:diagnosis, obat=:obat, tgl_rawat=:tgl_rawat WHERE id_rawat=:id_rawat";

        $stmt = $this->conn->prepare($query);

        $this->id_rawat=htmlspecialchars(strip_tags($this->id_rawat));
        $this->id_pasien=htmlspecialchars(strip_tags($this->id_pasien));
        $this->id_dokter=htmlspecialchars(strip_tags($this->id_dokter));
        $this->diagnosis=htmlspecialchars(strip_tags($this->diagnosis));
        $this->obat=htmlspecialchars(strip_tags($this->obat));
        $this->tgl_rawat=htmlspecialchars(strip_tags($this->tgl_rawat));

        $stmt->bindParam(":id_rawat", $this->id_rawat);
        $stmt->bindParam(":id_pasien", $this->id_pasien);
        $stmt->bindParam(":id_dokter", $this->id_dokter);
        $stmt->bindParam(":diagnosis", $this->diagnosis);
        $stmt->bindParam(":obat", $this->obat);
        $stmt->bindParam(":tgl_rawat", $this->tgl_rawat);

        if($stmt->execute()) {
            return true;
        }

        return false;
    }

    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id_rawat=:id_rawat";

        $stmt = $this->conn->prepare($query);

        $this->id_rawat=htmlspecialchars(strip_tags($this->id_rawat));

        $stmt->bindParam(":id_rawat", $this->id_rawat);

        if($stmt->execute()) {
            return true;
        }

        return false;
    }
}
?>
