<?php
class Dokter {
    private $conn;
    private $table_name = "dokter";

    public $id_dokter;
    public $nama;
    public $spesialis;
    public $alamat;
    public $hp;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Create dokter
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " SET id_dokter=:id_dokter, nama=:nama, spesialis=:spesialis, alamat=:alamat, hp=:hp";

        $stmt = $this->conn->prepare($query);

        $this->id_dokter=htmlspecialchars(strip_tags($this->id_dokter));
        $this->nama=htmlspecialchars(strip_tags($this->nama));
        $this->spesialis=htmlspecialchars(strip_tags($this->spesialis));
        $this->alamat=htmlspecialchars(strip_tags($this->alamat));
        $this->hp=htmlspecialchars(strip_tags($this->hp));

        $stmt->bindParam(":id_dokter", $this->id_dokter);
        $stmt->bindParam(":nama", $this->nama);
        $stmt->bindParam(":spesialis", $this->spesialis);
        $stmt->bindParam(":alamat", $this->alamat);
        $stmt->bindParam(":hp", $this->hp);

        if($stmt->execute()) {
            return true;
        }

        return false;
    }

    // Read dokter
    public function read() {
        $query = "SELECT * FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt;
    }

    // Update dokter
    public function update() {
        $query = "UPDATE " . $this->table_name . " SET nama=:nama, spesialis=:spesialis, alamat=:alamat, hp=:hp WHERE id_dokter=:id_dokter";

        $stmt = $this->conn->prepare($query);

        $this->id_dokter=htmlspecialchars(strip_tags($this->id_dokter));
        $this->nama=htmlspecialchars(strip_tags($this->nama));
        $this->spesialis=htmlspecialchars(strip_tags($this->spesialis));
        $this->alamat=htmlspecialchars(strip_tags($this->alamat));
        $this->hp=htmlspecialchars(strip_tags($this->hp));

        $stmt->bindParam(":id_dokter", $this->id_dokter);
        $stmt->bindParam(":nama", $this->nama);
        $stmt->bindParam(":spesialis", $this->spesialis);
        $stmt->bindParam(":alamat", $this->alamat);
        $stmt->bindParam(":hp", $this->hp);

        if($stmt->execute()) {
            return true;
        }

        return false;
    }

    // Delete dokter
    public function delete() {
        // Hapus semua data di tabel rawat yang berhubungan dengan dokter ini
        $query = "DELETE FROM rawat WHERE id_dokter = :id_dokter";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_dokter', $this->id_dokter);
        $stmt->execute();

        // Hapus dokter
        $query = "DELETE FROM " . $this->table_name . " WHERE id_dokter = :id_dokter";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_dokter', $this->id_dokter);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }
}
?>
