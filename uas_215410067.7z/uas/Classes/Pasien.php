<?php
class Pasien {
    private $conn;
    private $table_name = "pasien";

    public $id_pasien;
    public $nama;
    public $umur;
    public $jenis_kelamin;
    public $alamat;
    public $hp;
    public $riwayat_medis;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        $query = "INSERT INTO " . $this->table_name . " SET id_pasien=:id_pasien, nama=:nama, umur=:umur, jenis_kelamin=:jenis_kelamin, alamat=:alamat, hp=:hp, riwayat_medis=:riwayat_medis";

        $stmt = $this->conn->prepare($query);

        $this->id_pasien=htmlspecialchars(strip_tags($this->id_pasien));
        $this->nama=htmlspecialchars(strip_tags($this->nama));
        $this->umur=htmlspecialchars(strip_tags($this->umur));
        $this->jenis_kelamin=htmlspecialchars(strip_tags($this->jenis_kelamin));
        $this->alamat=htmlspecialchars(strip_tags($this->alamat));
        $this->hp=htmlspecialchars(strip_tags($this->hp));
        $this->riwayat_medis=htmlspecialchars(strip_tags($this->riwayat_medis));

        $stmt->bindParam(":id_pasien", $this->id_pasien);
        $stmt->bindParam(":nama", $this->nama);
        $stmt->bindParam(":umur", $this->umur);
        $stmt->bindParam(":jenis_kelamin", $this->jenis_kelamin);
        $stmt->bindParam(":alamat", $this->alamat);
        $stmt->bindParam(":hp", $this->hp);
        $stmt->bindParam(":riwayat_medis", $this->riwayat_medis);

        if($stmt->execute()) {
            return true;
        }

        return false;
    }

    public function read() {
        $query = "SELECT * FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt;
    }

    public function update() {
        $query = "UPDATE " . $this->table_name . " SET nama=:nama, umur=:umur, jenis_kelamin=:jenis_kelamin, alamat=:alamat, hp=:hp, riwayat_medis=:riwayat_medis WHERE id_pasien=:id_pasien";

        $stmt = $this->conn->prepare($query);

        $this->id_pasien=htmlspecialchars(strip_tags($this->id_pasien));
        $this->nama=htmlspecialchars(strip_tags($this->nama));
        $this->umur=htmlspecialchars(strip_tags($this->umur));
        $this->jenis_kelamin=htmlspecialchars(strip_tags($this->jenis_kelamin));
        $this->alamat=htmlspecialchars(strip_tags($this->alamat));
        $this->hp=htmlspecialchars(strip_tags($this->hp));
        $this->riwayat_medis=htmlspecialchars(strip_tags($this->riwayat_medis));

        $stmt->bindParam(":id_pasien", $this->id_pasien);
        $stmt->bindParam(":nama", $this->nama);
        $stmt->bindParam(":umur", $this->umur);
        $stmt->bindParam(":jenis_kelamin", $this->jenis_kelamin);
        $stmt->bindParam(":alamat", $this->alamat);
        $stmt->bindParam(":hp", $this->hp);
        $stmt->bindParam(":riwayat_medis", $this->riwayat_medis);

        if($stmt->execute()) {
            return true;
        }

        return false;
    }

    public function delete()
    {
        // Hapus semua data di tabel rawat yang berhubungan dengan pasien ini
        $query = "DELETE FROM rawat WHERE id_pasien = :id_pasien";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_pasien', $this->id_pasien);
        $stmt->execute();

        // Hapus pasien
        $query = "DELETE FROM " . $this->table_name . " WHERE id_pasien = :id_pasien";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id_pasien', $this->id_pasien);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }
}
?>
